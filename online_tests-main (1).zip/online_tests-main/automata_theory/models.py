import os
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse
import uuid


class Group(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название группы", unique=True)

    def __str__(self):
        return self.name


class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        (0, "Преподаватель"),
        (1, "Ученик"),
    ]

    first_name = models.TextField(blank=True, verbose_name="Имя")
    last_name = models.TextField(blank=True, verbose_name="Фамилия")
    role = models.IntegerField(
        blank=False, verbose_name="Роль пользователя", choices=ROLE_CHOICES, default=1
    )
    group = models.ForeignKey(
        Group, on_delete=models.CASCADE, verbose_name="Группа", null=True, blank=True
    )

    def get_absolute_url(self):
        return reverse("user-profile", kwargs={"username": self.username})

    def get_update_url(self):
        return reverse("update_profile", kwargs={"username": self.username})

    def get_delete_url(self):
        return reverse("post_delete_url", kwargs={"username": self.username})

    def save(self, *args, **kwargs):
        if self.role == 0:
            self.is_superuser = True
        else:
            self.is_superuser = False
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            self.last_name + " " + self.first_name + " " + self.group.name
            if self.group
            else ""
        )


class KRTime(models.Model):
    KR_CHOICES = [
        (1, "Контрольная работа №1"),
        (2, "Контрольная работа №2"),
        (3, "Контрольная работа №3"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    kr_number = models.IntegerField(
        choices=KR_CHOICES, verbose_name="Номер контрольной работы"
    )
    duration = models.DurationField(
        verbose_name="Длительность контрольной работы", default="01:30:00"
    )
    is_active = models.BooleanField(default=True, verbose_name="Активна ли запись")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата обновления")

    class Meta:
        verbose_name = "Время контрольной работы"
        verbose_name_plural = "Время контрольных работ"
        ordering = ["kr_number"]

    def __str__(self):
        return f"КР №{self.kr_number} (Длительность: {self.duration})"


def bcfile_directory_path(instance, filename):
    """
    Путь к директории для сохранения файлов контрольных работ
    """

    return os.path.join(
        "bc_files", f"kr_{instance.kr_number}", str(instance.id), filename
    )


class BCFile(models.Model):
    KR_CHOICES = [
        (1, "Контрольная работа №1"),
        (2, "Контрольная работа №2"),
        (3, "Контрольная работа №3"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    kr_number = models.IntegerField(
        choices=KR_CHOICES, verbose_name="Номер контрольной работы"
    )
    file = models.FileField(
        upload_to=bcfile_directory_path, verbose_name="Файл контрольной работы"
    )
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        verbose_name="Пользователь",
        related_name="bc_files",
    )
    border_control_id = models.UUIDField(blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата загрузки")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата обновления")

    def __str__(self):
        return f"КР-{self.kr_number} {self.file.name.split('/')[-1]}"

    class Meta:
        verbose_name = "Файл контрольной работы"
        verbose_name_plural = "Файлы контрольных работ"
        ordering = ["-uploaded_at"]
