from django.db import models
from django.conf import settings
import json

from automata_theory.models import CustomUser


class Variant(models.Model):
    BASE_TYPES = [
        ("and_or_not", "И-ИЛИ-НЕ"),
        ("not_and", "НЕ-И"),
        ("not_or", "НЕ-ИЛИ"),
    ]

    karnaugh_letter = models.CharField(max_length=1)
    karnaugh_offset = models.IntegerField(default=0)
    base_type = models.CharField(
        max_length=20, choices=BASE_TYPES, default="and_or_not"
    )
    truth_table = models.JSONField(default=list)

    answers = models.ForeignKey(
        "AnswersBC3",
        on_delete=models.CASCADE,
        verbose_name="Ожидаемые ответы",
        related_name="variant",
    )

    def __str__(self):
        return f"Вариант {self.karnaugh_letter} {self.karnaugh_offset} {self.base_type}"


class BorderControl3(models.Model):
    """Модель для контрольной работы по картам Карно"""

    user = models.ForeignKey(
        CustomUser, on_delete=models.CASCADE, verbose_name="Пользователь"
    )
    variant = models.ForeignKey(
        Variant, blank=True, null=True, on_delete=models.SET_NULL
    )
    created_at = models.DateTimeField(auto_now_add=True)

    results = models.ForeignKey(
        "ResultsBC3",
        on_delete=models.CASCADE,
        verbose_name="Пользовательские ответы",
        blank=True,
        null=True,
    )

    rating = models.FloatField(null=True, blank=True)
    result_number = models.IntegerField(null=True, blank=True)

    class Meta:
        verbose_name = "РК номер 2"
        verbose_name_plural = "РК номер 2"
        get_latest_by = "created_at"

    def __str__(self):
        return f"КР3 {self.user.username} - {self.created_at.strftime('%d.%m.%Y')}"


class AnswersBC3(models.Model):
    """Модель для правильных ответов контрольной работы 3"""

    created_at = models.DateTimeField(auto_now_add=True)

    pair_0_0 = models.CharField(max_length=2, default="0")  # индекс для строки 0
    pair_2_0 = models.CharField(max_length=1, default="0")  # значение для строки 0
    pair_0_1 = models.CharField(max_length=2, default="0")
    pair_2_1 = models.CharField(max_length=1, default="0")
    pair_0_2 = models.CharField(max_length=2, default="0")
    pair_2_2 = models.CharField(max_length=1, default="0")
    pair_0_3 = models.CharField(max_length=2, default="0")
    pair_2_3 = models.CharField(max_length=1, default="0")
    pair_0_4 = models.CharField(max_length=2, default="0")
    pair_2_4 = models.CharField(max_length=1, default="0")
    pair_0_5 = models.CharField(max_length=2, default="0")
    pair_2_5 = models.CharField(max_length=1, default="0")
    pair_0_6 = models.CharField(max_length=2, default="0")
    pair_2_6 = models.CharField(max_length=1, default="0")
    pair_0_7 = models.CharField(max_length=2, default="0")
    pair_2_7 = models.CharField(max_length=1, default="0")
    pair_0_8 = models.CharField(max_length=2, default="0")
    pair_2_8 = models.CharField(max_length=1, default="0")
    pair_0_9 = models.CharField(max_length=2, default="0")
    pair_2_9 = models.CharField(max_length=1, default="0")
    pair_0_10 = models.CharField(max_length=2, default="0")
    pair_2_10 = models.CharField(max_length=1, default="0")
    pair_0_11 = models.CharField(max_length=2, default="0")
    pair_2_11 = models.CharField(max_length=1, default="0")
    pair_0_12 = models.CharField(max_length=2, default="0")
    pair_2_12 = models.CharField(max_length=1, default="0")
    pair_0_13 = models.CharField(max_length=2, default="0")
    pair_2_13 = models.CharField(max_length=1, default="0")
    pair_0_14 = models.CharField(max_length=2, default="0")
    pair_2_14 = models.CharField(max_length=1, default="0")
    pair_0_15 = models.CharField(max_length=2, default="0")
    pair_2_15 = models.CharField(max_length=1, default="0")

    # Значения карты Карно (правильные)
    cell_0 = models.CharField(max_length=1, default="0")
    cell_1 = models.CharField(max_length=1, default="0")
    cell_2 = models.CharField(max_length=1, default="0")
    cell_3 = models.CharField(max_length=1, default="0")
    cell_4 = models.CharField(max_length=1, default="0")
    cell_5 = models.CharField(max_length=1, default="0")
    cell_6 = models.CharField(max_length=1, default="0")
    cell_7 = models.CharField(max_length=1, default="0")
    cell_8 = models.CharField(max_length=1, default="0")
    cell_9 = models.CharField(max_length=1, default="0")
    cell_10 = models.CharField(max_length=1, default="0")
    cell_11 = models.CharField(max_length=1, default="0")
    cell_12 = models.CharField(max_length=1, default="0")
    cell_13 = models.CharField(max_length=1, default="0")
    cell_14 = models.CharField(max_length=1, default="0")
    cell_15 = models.CharField(max_length=1, default="0")

    # Минимальные формы (правильные)
    sdnf = models.TextField(blank=True)
    sknf = models.TextField(blank=True)
    base_expression_sdnf = models.TextField(blank=True)
    base_expression_sknf = models.TextField(blank=True)

    # Метод Квайна (правильные)
    quine_sdnf = models.TextField(blank=True)
    quine_sknf = models.TextField(blank=True)

    # Метод Квайна-МакКласки (правильные)
    quine_mccluskey_sdnf = models.TextField(blank=True)
    quine_mccluskey_sknf = models.TextField(blank=True)

    class Meta:
        verbose_name = "Ожидаемые ответы РК 2"
        verbose_name_plural = "Ожидаемые ответы РК 2"
        ordering = ["-created_at"]
        get_latest_by = "created_at"

    def __str__(self):
        return f"Ответы КР3 - {self.created_at.strftime('%d.%m.%Y %H:%M')}"

    def get_tests(self):
        """Получить связанные контрольные работы"""
        return BorderControl3.objects.filter(answers=self)


class ResultsBC3(models.Model):
    """Модель для результатов контрольной работы 3"""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    pair_0_0 = models.CharField(max_length=2, default="0")  # индекс для строки 0
    pair_2_0 = models.CharField(max_length=1, default="0")  # значение для строки 0
    pair_0_1 = models.CharField(max_length=2, default="0")
    pair_2_1 = models.CharField(max_length=1, default="0")
    pair_0_2 = models.CharField(max_length=2, default="0")
    pair_2_2 = models.CharField(max_length=1, default="0")
    pair_0_3 = models.CharField(max_length=2, default="0")
    pair_2_3 = models.CharField(max_length=1, default="0")
    pair_0_4 = models.CharField(max_length=2, default="0")
    pair_2_4 = models.CharField(max_length=1, default="0")
    pair_0_5 = models.CharField(max_length=2, default="0")
    pair_2_5 = models.CharField(max_length=1, default="0")
    pair_0_6 = models.CharField(max_length=2, default="0")
    pair_2_6 = models.CharField(max_length=1, default="0")
    pair_0_7 = models.CharField(max_length=2, default="0")
    pair_2_7 = models.CharField(max_length=1, default="0")
    pair_0_8 = models.CharField(max_length=2, default="0")
    pair_2_8 = models.CharField(max_length=1, default="0")
    pair_0_9 = models.CharField(max_length=2, default="0")
    pair_2_9 = models.CharField(max_length=1, default="0")
    pair_0_10 = models.CharField(max_length=2, default="0")
    pair_2_10 = models.CharField(max_length=1, default="0")
    pair_0_11 = models.CharField(max_length=2, default="0")
    pair_2_11 = models.CharField(max_length=1, default="0")
    pair_0_12 = models.CharField(max_length=2, default="0")
    pair_2_12 = models.CharField(max_length=1, default="0")
    pair_0_13 = models.CharField(max_length=2, default="0")
    pair_2_13 = models.CharField(max_length=1, default="0")
    pair_0_14 = models.CharField(max_length=2, default="0")
    pair_2_14 = models.CharField(max_length=1, default="0")
    pair_0_15 = models.CharField(max_length=2, default="0")
    pair_2_15 = models.CharField(max_length=1, default="0")

    # Значения карты Карно
    cell_0 = models.CharField(max_length=1, default="0")
    cell_1 = models.CharField(max_length=1, default="0")
    cell_2 = models.CharField(max_length=1, default="0")
    cell_3 = models.CharField(max_length=1, default="0")
    cell_4 = models.CharField(max_length=1, default="0")
    cell_5 = models.CharField(max_length=1, default="0")
    cell_6 = models.CharField(max_length=1, default="0")
    cell_7 = models.CharField(max_length=1, default="0")
    cell_8 = models.CharField(max_length=1, default="0")
    cell_9 = models.CharField(max_length=1, default="0")
    cell_10 = models.CharField(max_length=1, default="0")
    cell_11 = models.CharField(max_length=1, default="0")
    cell_12 = models.CharField(max_length=1, default="0")
    cell_13 = models.CharField(max_length=1, default="0")
    cell_14 = models.CharField(max_length=1, default="0")
    cell_15 = models.CharField(max_length=1, default="0")

    # Минимальные формы
    sdnf = models.TextField(blank=True)
    sknf = models.TextField(blank=True)
    base_expression_sdnf = models.TextField(blank=True)
    base_expression_sknf = models.TextField(blank=True)
    # Метод Квайна
    quine_sdnf = models.TextField(blank=True)
    quine_sknf = models.TextField(blank=True)

    # Метод Квайна-МакКласки
    quine_mccluskey_sdnf = models.TextField(blank=True)
    quine_mccluskey_sknf = models.TextField(blank=True)

    # Оценка и номер результата
    rating = models.FloatField(null=True, blank=True)
    result_number = models.IntegerField(null=True, blank=True)

    class Meta:
        verbose_name = "Пользовательские ответы РК2"
        verbose_name_plural = "Пользовательские ответы РК2"
        ordering = ["-created_at"]
        get_latest_by = "created_at"

    def __str__(self):
        return f"Результат КР3 {self.user.username} - {self.created_at.strftime('%d.%m.%Y %H:%M')}"

    def get_test(self):
        """Получить связанную контрольную работу"""
        try:
            return BorderControl3.objects.get(results=self)
        except BorderControl3.DoesNotExist:
            return None
