# helpers.py
import json
import random
from typing import List, Dict, Set, Tuple
from .models import BorderControl3, ResultsBC3, AnswersBC3


class KarnaughHelper:
    """Класс-помощник для работы с картами Карно"""

    # Списки значений для каждой буквы (16 элементов: 0-15)
    LETTER_LISTS = {
        'a': ['1', '0', '0', '0', '1', '1', '0', '0', '1', '1', 'x', 'x', 'x', 'x', 'x', 'x'],
        'b': ['1', '0', '1', '1', '0', '1', '0', '1', '1', '1', 'x', 'x', 'x', 'x', 'x', 'x'],
        'c': ['1', '1', '1', '0', '1', '0', '0', '0', '1', '1', 'x', 'x', 'x', 'x', 'x', 'x'],
        'd': ['1', '1', '0', '0', '1', '1', '1', '0', '1', '0', 'x', 'x', 'x', 'x', 'x', 'x'],
        'e': ['1', '0', '1', '0', '0', '1', '1', '0', '1', '0', 'x', 'x', 'x', 'x', 'x', 'x'],
        'f': ['1', '0', '0', '0', '0', '0', '1', '0', '1', '0', 'x', 'x', 'x', 'x', 'x', 'x'],
        'l': ['0', '1', '0', '1', '0', '0', '1', '1', '0', '0', 'x', 'x', 'x', 'x', 'x', 'x'],
        'g': ['0', '0', '0', '1', '1', '1', '1', '0', '1', '0', 'x', 'x', 'x', 'x', 'x', 'x'],
        'm': ['0', '0', '1', '1', '0', '0', '0', '0', '0', '1', 'x', 'x', 'x', 'x', 'x', 'x']
    }

    @classmethod
    def cyclic_shift_list(cls, values, offset):
        """Циклический сдвиг всего списка"""
        if offset == 0:
            return values.copy()

        # Простой циклический сдвиг всего списка
        n = len(values)
        offset = offset % n
        shifted = values[-offset:] + values[:-offset]

        return shifted

    @classmethod
    def list_to_pairs(cls, values):
        """Преобразует список в пары (индекс, значение)"""
        return [(i, values[i]) for i in range(len(values))]

    @classmethod
    def get_shifted_list(cls, letter, offset):
        """Получить сдвинутый список для буквы"""
        if letter not in cls.LETTER_LISTS:
            raise ValueError(f"Неизвестная буква: {letter}")
        return cls.cyclic_shift_list(cls.LETTER_LISTS[letter], offset)

    @classmethod
    def get_shifted_pairs(cls, letter, offset):
        """Получить сдвинутые пары для буквы"""
        shifted_list = cls.get_shifted_list(letter, offset)
        return cls.list_to_pairs(shifted_list)

    @classmethod
    def list_to_karnaugh_map(cls, values: List[str]) -> List[List[str]]:
        """Преобразование списка значений в карту Карно 4x4"""
        return [
            [values[0], values[1], values[3], values[2]],  # строка 0
            [values[4], values[5], values[7], values[6]],  # строка 1
            [values[12], values[13], values[15], values[14]],  # строка 2
            [values[8], values[9], values[11], values[10]]  # строка 3
        ]

    @classmethod
    def create_karnaugh_from_letter(cls, letter: str, offset: int = 0) -> List[List[str]]:
        """Создание карты Карно из буквы и смещения"""
        shifted_list = cls.get_shifted_list(letter, offset)
        return cls.list_to_karnaugh_map(shifted_list)

    @classmethod
    def map_to_string(cls, map_data: List[List[str]]) -> str:
        """Преобразование карты в строку для хранения"""
        return json.dumps(map_data)

    @classmethod
    def string_to_map(cls, map_str: str) -> List[List[str]]:
        """Восстановление карты из строки"""
        return json.loads(map_str)

    @classmethod
    def validate_map(cls, map_data: List[List[str]]) -> bool:
        """Валидация карты Карно"""
        if not map_data:
            return False

        rows = len(map_data)
        if rows not in [2, 4, 8]:
            return False

        for row in map_data:
            if len(row) not in [2, 4, 8]:
                return False
            for cell in row:
                if cell not in ['0', '1', 'x', '-']:
                    return False

        return True

    @classmethod
    def get_available_letters(cls) -> List[str]:
        """Получить список доступных букв"""
        return list(cls.LETTER_LISTS.keys())


class QuineMcCluskey:
    """
    Класс для минимизации логических функций методом Квайна-МакКласки
    """

    @staticmethod
    def get_minterms(ones: List[int], dc: List[int] = None) -> List[int]:
        """Получение списка минтермов из единиц и прочерков"""
        if dc is None:
            dc = []
        return sorted(ones + dc)

    @staticmethod
    def int_to_bin(x: int, num_vars: int) -> str:
        """Преобразование числа в двоичное представление с ведущими нулями"""
        return bin(x)[2:].zfill(num_vars)

    @staticmethod
    def count_ones(binary: str) -> int:
        """Подсчет количества единиц в двоичном числе"""
        return binary.count('1')

    @staticmethod
    def group_terms(terms: List[str]) -> dict:
        """Группировка термов по количеству единиц"""
        groups = {}
        for term in terms:
            ones = term.count('1')
            if ones not in groups:
                groups[ones] = []
            groups[ones].append(term)
        return groups

    @staticmethod
    def compare_terms(term1: str, term2: str) -> str:
        """Сравнение двух термов и нахождение их склейки"""
        diff = 0
        result = []
        for a, b in zip(term1, term2):
            if a != b:
                diff += 1
                result.append('-')
                if diff > 1:
                    return None
            else:
                result.append(a)
        return ''.join(result) if diff == 1 else None

    @staticmethod
    def find_prime_implicants(minterms: List[int], num_vars: int) -> List[str]:
        """Нахождение простых импликант методом Квайна-МакКласки"""
        # Преобразуем минтермы в двоичный вид
        binary_terms = [QuineMcCluskey.int_to_bin(m, num_vars) for m in minterms]

        # Группируем термы по количеству единиц
        groups = QuineMcCluskey.group_terms(binary_terms)

        prime_implicants = set()

        while True:
            new_implicants = set()
            used = set()

            # Сравниваем каждую группу с соседней
            keys = sorted(groups.keys())
            for i in range(len(keys) - 1):
                for term1 in groups[keys[i]]:
                    for term2 in groups[keys[i + 1]]:
                        combined = QuineMcCluskey.compare_terms(term1, term2)
                        if combined:
                            used.add(term1)
                            used.add(term2)
                            new_implicants.add(combined)

            # Добавляем неиспользованные термы в простые импликанты
            for group in groups.values():
                for term in group:
                    if term not in used:
                        prime_implicants.add(term)

            if not new_implicants:
                break

            # Обновляем группы для следующей итерации
            groups = QuineMcCluskey.group_terms(list(new_implicants))

        return sorted(prime_implicants)

    @staticmethod
    def is_covered(term: str, minterm: str) -> bool:
        """Проверяет, покрывает ли импликанта минтерм"""
        for t, m in zip(term, minterm):
            if t != '-' and t != m:
                return False
        return True

    @staticmethod
    def minimize(ones: List[int], dc: List[int] = None, num_vars: int = 4) -> str:
        """
        Минимизация логической функции методом Квайна-МакКласки

        Аргументы:
            ones: список индексов, где функция принимает значение 1
            dc: список индексов, где функция не определена (don't care)
            num_vars: количество переменных (по умолчанию 4 для карты 4x4)

        Возвращает:
            Строку с минимальной ДНФ
        """
        if dc is None:
            dc = []

        minterms = QuineMcCluskey.get_minterms(ones, dc)
        prime_implicants = QuineMcCluskey.find_prime_implicants(minterms, num_vars)

        # Преобразуем простые импликанты в читаемый вид
        variables = ['A', 'B', 'C', 'D']
        result = []

        for imp in prime_implicants:
            terms = []
            for var, val in zip(variables, imp):
                if val == '0':
                    terms.append(f'¬{var}')
                elif val == '1':
                    terms.append(var)
            if terms:
                result.append(' & '.join(terms))

        return ' V '.join(result) if result else '0'


def generate_random_karnaugh_map() -> dict:
    """
    Генерирует случайную карту Карно с одним из доступных шаблонов букв

    Returns:
        dict: Словарь с данными карты Карно
            {
                'pattern': List[str] - список значений (0, 1, 'x') длиной 16,
                'letter': str - буква шаблона,
                'offset': int - смещение
            }
    """
    # Выбираем случайную букву из доступных шаблонов
    available_letters = list(KarnaughHelper.LETTER_LISTS.keys())
    letter = random.choice(available_letters)

    # Генерируем случайное смещение (0-15)
    offset = random.randint(0, 6)

    # Получаем базовый шаблон для выбранной буквы
    base_pattern = KarnaughHelper.LETTER_LISTS[letter]

    # Применяем циклический сдвиг к шаблону
    rotated_pattern = base_pattern[offset:] + base_pattern[:offset]

    return {
        'pattern': rotated_pattern,
        'letter': letter.upper(),
        'offset': offset
    }


class ExpressionConverter:
    """Класс для преобразования логических выражений между разными базисами"""

    @staticmethod
    def to_nand(expression: str) -> str:
        """Преобразование выражения в базис Шеффера (NAND)"""
        if not expression:
            return ""

        # Упрощенная реализация - в реальном приложении нужно парсить выражение
        expression = expression.replace('!', ' NOT ')
        expression = expression.replace('&', ' NAND ')
        expression = expression.replace('+', ' NAND ')

        # Упрощение двойных отрицаний
        while 'NOT NOT ' in expression:
            expression = expression.replace('NOT NOT ', '')

        return expression.strip()

    @staticmethod
    def to_nor(expression: str) -> str:
        """Преобразование выражения в базис Пирса (NOR)"""
        if not expression:
            return ""

        # Упрощенная реализация - в реальном приложении нужно парсить выражение
        expression = expression.replace('!', ' NOT ')
        expression = expression.replace('&', ' NOR ')
        expression = expression.replace('+', ' NOR ')

        # Упрощение двойных отрицаний
        while 'NOT NOT ' in expression:
            expression = expression.replace('NOT NOT ', '')

        return expression.strip()

    @staticmethod
    def convert(expression: str, target_base: str) -> str:
        """
        Преобразование выражения в указанный базис

        Аргументы:
            expression: исходное логическое выражение
            target_base: целевой базис ('and_or_not', 'not_and', 'not_or')

        Возвращает:
            Преобразованное выражение
        """
        if target_base == 'and_or_not':
            return expression
        elif target_base == 'not_and':
            return ExpressionConverter.to_nand(expression)
        elif target_base == 'not_or':
            return ExpressionConverter.to_nor(expression)
        return expression


class LogicMinimizer:
    """Класс для минимизации логических функций с использованием прочерков"""

    @staticmethod
    def gray_code_2bit():
        return ['00', '01', '11', '10']

    @staticmethod
    def get_variable_combination(row: int, col: int, rows: int, cols: int, variables: List[str]) -> str:
        """Получение комбинации переменных для ячейки"""
        if rows == 4 and cols == 4:
            row_codes = LogicMinimizer.gray_code_2bit()
            col_codes = LogicMinimizer.gray_code_2bit()
            combination = row_codes[row] + col_codes[col]
            return combination[:len(variables)]
        elif rows == 2 and cols == 4:
            row_codes = ['0', '1']
            col_codes = LogicMinimizer.gray_code_2bit()
            combination = row_codes[row] + col_codes[col]
            return combination[:len(variables)]
        elif rows == 2 and cols == 2:
            row_codes = ['0', '1']
            col_codes = ['0', '1']
            combination = row_codes[row] + col_codes[col]
            return combination[:len(variables)]
        return ""

    @staticmethod
    def find_implicants(map_data: List[List[str]], variables: List[str]) -> List[tuple]:
        """Нахождение всех возможных импликант с использованием прочерков"""
        rows = len(map_data)
        cols = len(map_data[0]) if map_data else 0

        # Собираем все минтермы (1) и прочерки
        ones_and_dc = []
        for i in range(rows):
            for j in range(cols):
                if map_data[i][j] in ['1', 'x', '-']:
                    combination = LogicMinimizer.get_variable_combination(i, j, rows, cols, variables)
                    ones_and_dc.append((combination, (i, j)))

        # Группируем по количеству единиц
        groups = {}
        for comb, pos in ones_and_dc:
            ones_count = comb.count('1')
            if ones_count not in groups:
                groups[ones_count] = []
            groups[ones_count].append((comb, [pos]))

        prime_implicants = []

        # Алгоритм Куайна-МакКласки (упрощенный)
        while groups:
            new_groups = {}
            used = set()

            keys = sorted(groups.keys())
            for i in range(len(keys) - 1):
                if keys[i] + 1 == keys[i + 1]:
                    for term1, pos1 in groups[keys[i]]:
                        for term2, pos2 in groups[keys[i + 1]]:
                            # Проверяем различие в одном бите
                            diff_count = 0
                            diff_pos = -1
                            for idx in range(len(term1)):
                                if term1[idx] != term2[idx]:
                                    diff_count += 1
                                    diff_pos = idx

                            if diff_count == 1:
                                new_term = term1[:diff_pos] + '-' + term1[diff_pos + 1:]
                                new_pos = pos1 + pos2

                                if keys[i] not in new_groups:
                                    new_groups[keys[i]] = []
                                new_groups[keys[i]].append((new_term, new_pos))

                                used.add(term1)
                                used.add(term2)

            # Добавляем непокрытые термины в простые импликанты
            for key in groups:
                for term, pos in groups[key]:
                    if term not in used:
                        # Проверяем, что импликанта покрывает хотя бы одну единицу
                        covers_one = False
                        for (r, c) in pos:
                            if map_data[r][c] in ['1']:
                                covers_one = True
                                break
                        if covers_one:
                            prime_implicants.append((term, pos))

            groups = new_groups

        return prime_implicants

    @staticmethod
    def minimal_dnf(map_data: List[List[str]], variables: List[str]) -> str:
        """Нахождение минимальной ДНФ с использованием прочерков"""
        rows = len(map_data)
        cols = len(map_data[0]) if map_data else 0

        # Находим все единицы (для покрытия)
        ones_positions = []
        for i in range(rows):
            for j in range(cols):
                if map_data[i][j] == '1':
                    ones_positions.append((i, j))

        if not ones_positions:
            return "0"

        if len(ones_positions) == rows * cols:
            return "1"

        # Находим все простые импликанты
        prime_implicants = LogicMinimizer.find_implicants(map_data, variables)

        if not prime_implicants:
            return "0"

        # Простой алгоритм покрытия
        covered_ones = set()
        selected_implicants = []

        # Сортируем импликанты по размеру (чем больше прочерков, тем лучше)
        prime_implicants.sort(key=lambda x: x[0].count('-'), reverse=True)

        for implicant, positions in prime_implicants:
            # Проверяем, покрывает ли эта импликанта новые единицы
            covers_new = False
            for pos in positions:
                r, c = pos
                if map_data[r][c] == '1' and pos not in covered_ones:
                    covers_new = True
                    break

            if covers_new:
                selected_implicants.append(implicant)
                # Добавляем все покрываемые единицы
                for pos in positions:
                    r, c = pos
                    if map_data[r][c] == '1':
                        covered_ones.add(pos)

        # Если какие-то единицы не покрыты, добавляем минимальные импликанты
        if len(covered_ones) < len(ones_positions):
            uncovered = set(ones_positions) - covered_ones
            for pos in uncovered:
                r, c = pos
                comb = LogicMinimizer.get_variable_combination(r, c, rows, cols, variables)
                selected_implicants.append(comb)

        # Преобразуем импликанты в логические выражения
        terms = []
        for implicant in selected_implicants:
            term_parts = []
            for idx, var in enumerate(variables):
                if idx < len(implicant):
                    if implicant[idx] == '0':
                        term_parts.append(f"¬{var}")
                    elif implicant[idx] == '1':
                        term_parts.append(var)
            if term_parts:
                terms.append(" & ".join(term_parts))
            else:
                terms.append("1")

        # Удаляем дубликаты
        terms = list(set(terms))

        return " V ".join([f"({term})" for term in terms]) if terms else "0"

    @staticmethod
    def minimal_cnf(map_data: List[List[str]], variables: List[str]) -> str:
        """Нахождение минимальной КНФ с использованием прочерков"""
        rows = len(map_data)
        cols = len(map_data[0]) if map_data else 0

        # Находим все нули (для покрытия)
        zeros_positions = []
        for i in range(rows):
            for j in range(cols):
                if map_data[i][j] == '0':
                    zeros_positions.append((i, j))

        if not zeros_positions:
            return "1"

        if len(zeros_positions) == rows * cols:
            return "0"

        # Для КНФ используем дуальность - инвертируем карту
        inverted_map = []
        for i in range(rows):
            row = []
            for j in range(cols):
                if map_data[i][j] == '0':
                    row.append('1')
                elif map_data[i][j] == '1':
                    row.append('0')
                else:
                    row.append('x')
            inverted_map.append(row)

        # Находим минимальную ДНФ для инвертированной функции
        minimal_dnf_inverted = LogicMinimizer.minimal_dnf(inverted_map, variables)

        if minimal_dnf_inverted == "0":
            return "1"
        elif minimal_dnf_inverted == "1":
            return "0"

        # Упрощенное преобразование ДНФ в КНФ
        cnf_terms = []
        dnf_terms = minimal_dnf_inverted.split(' V ')

        for term in dnf_terms:
            term = term.strip('()')
            literals = term.split(' & ')
            cnf_literals = []
            for literal in literals:
                if literal.startswith('¬'):
                    cnf_literals.append(literal[1:])
                else:
                    cnf_literals.append(f"¬{literal}")
            cnf_terms.append(" V ".join(cnf_literals))

        return " & ".join([f"({term})" for term in cnf_terms])


def create_karnaugh_control(user):
    """Создает контрольную работу по картам Карно"""
    # Получаем доступные буквы
    available_letters = list(KarnaughHelper.LETTER_LISTS.keys())
    karnaugh_letter = random.choice(available_letters)
    karnaugh_offset = random.randint(0, 15)

    # Генерируем таблицу истинности С УЧЕТОМ СДВИГА
    truth_table = KarnaughHelper.get_shifted_list(karnaugh_letter, karnaugh_offset)

    # Получаем базовый паттерн БЕЗ сдвига для вычисления pair_0_i
    base_pattern = KarnaughHelper.LETTER_LISTS[karnaugh_letter]

    # Выбираем случайный базис
    base_type = random.choice(['and_or_not', 'not_and', 'not_or'])

    # Создаем объект с правильными ответами
    answers = AnswersBC3.objects.create(
        # Заполняем правильные значения карты Карно
        cell_0=truth_table[0],
        cell_1=truth_table[1],
        cell_2=truth_table[2],
        cell_3=truth_table[3],
        cell_4=truth_table[4],
        cell_5=truth_table[5],
        cell_6=truth_table[6],
        cell_7=truth_table[7],
        cell_8=truth_table[8],
        cell_9=truth_table[9],
        cell_10=truth_table[10],
        cell_11=truth_table[11],
        cell_12=truth_table[12],
        cell_13=truth_table[13],
        cell_14=truth_table[14],
        cell_15=truth_table[15],
    )

    # Заполняем правильные значения для pair_0_i и pair_2_i
    # Формула: pair_0_i = (i + karnaugh_offset) % 16
    # pair_2_i = truth_table[i] (уже со сдвигом!)
    for i in range(16):
        # Вычисляем правильное значение pair_0_i
        correct_pair_0 = str((i + karnaugh_offset) % 16)

        # Правильное значение pair_2_i - из таблицы истинности (уже со сдвигом)
        correct_pair_2 = truth_table[i] if i < len(truth_table) else '0'

        setattr(answers, f'pair_0_{i}', correct_pair_0)
        setattr(answers, f'pair_2_{i}', correct_pair_2)

    # Вычисляем правильные минимальные формы
    karnaugh_map = KarnaughHelper.list_to_karnaugh_map(truth_table)
    variables = ['A', 'B', 'C', 'D']

    # Находим минтермы и безразличные состояния
    ones = []
    dc = []
    for i, val in enumerate(truth_table):
        if val == '1':
            ones.append(i)
        elif val == 'x':
            dc.append(i)

    answers.sdnf = "Ошибка вычисления"
    answers.sknf = "Ошибка вычисления"
    answers.quine_sdnf = "Ошибка вычисления"
    answers.quine_sknf = "Ошибка вычисления"
    answers.quine_mccluskey_sdnf = "Ошибка вычисления"
    answers.quine_mccluskey_sknf = "Ошибка вычисления"

    answers.save()

    # Создаем контрольную работу
    control = BorderControl3.objects.create(
        user=user,
        karnaugh_letter=karnaugh_letter,
        karnaugh_offset=karnaugh_offset,
        base_type=base_type,
        truth_table=truth_table,
        answers=answers  # Связываем с правильными ответами
    )

    return control


def get_karnaugh_results_and_rating(control, results):
    """Вычисляет результаты и оценку для контрольной работы"""
    correct_answers = control.answers
    score = 0
    total_fields = 22  # 16 ячеек карты + 6 текстовых полей

    # Проверяем карту Карно (16 полей)
    cell_fields = ['cell_0', 'cell_1', 'cell_2', 'cell_3', 'cell_4', 'cell_5', 'cell_6', 'cell_7',
                   'cell_8', 'cell_9', 'cell_10', 'cell_11', 'cell_12', 'cell_13', 'cell_14', 'cell_15']

    for field in cell_fields:
        user_value = getattr(results, field, '0').upper()
        correct_value = getattr(correct_answers, field, '0').upper()
        if user_value == correct_value:
            score += 1

    # Проверяем текстовые поля (6 полей)
    text_fields = ['sdnf', 'sknf', 'quine_sdnf', 'quine_sknf', 'quine_mccluskey_sdnf', 'quine_mccluskey_sknf']

    for field in text_fields:
        user_value = getattr(results, field, '').strip()
        correct_value = getattr(correct_answers, field, '').strip()
        # Упрощенная проверка - считаем правильным если не пустое
        if user_value and user_value != "Ошибка вычисления":
            score += 1

    # Вычисляем оценку (максимум 5)
    rating = round((score / total_fields) * 5, 2)

    # Вычисляем номер результата
    result_number = ResultsBC3.objects.filter(user=control.user).count()

    return rating, result_number