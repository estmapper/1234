# admin.py
import json

from django.contrib import admin
from django import forms
from django.db.models import JSONField

from .models import Variant, BorderControl3, AnswersBC3, ResultsBC3


class PrettyJSONWidget(forms.Textarea):
    """Простой виджет для красивого отображения JSON в админке."""

    def format_value(self, value):
        if value in (None, "", []):
            return "[]"
        try:
            return json.dumps(value, ensure_ascii=False, indent=2)
        except Exception:
            return super().format_value(value)


class VariantInline(admin.TabularInline):
    model = Variant
    extra = 0
    fields = ("karnaugh_letter", "karnaugh_offset", "base_type", "truth_table")
    readonly_fields = ()
    show_change_link = True


@admin.register(AnswersBC3)
class AnswersBC3Admin(admin.ModelAdmin):
    date_hierarchy = "created_at"
    ordering = ("-created_at",)
    list_display = (
        "id",
        "created_at",
    )
    search_fields = ["created_at"]
    inlines = (VariantInline,)

    # Чтобы не держать на форме огромные fieldsets, обычно лучше collapsed-блоки.
    fieldsets = (
        ("Общее", {"fields": ("created_at",)}),
        (
            "Пары",
            {
                "classes": ("collapse",),
                "fields": tuple(
                    f for i in range(16) for f in (f"pair_0_{i}", f"pair_2_{i}")
                ),
            },
        ),
        (
            "Карта Карно",
            {"classes": ("collapse",), "fields": tuple(f"cell_{i}" for i in range(16))},
        ),
        (
            "Минимальные формы",
            {
                "classes": ("collapse",),
                "fields": (
                    "sdnf",
                    "sknf",
                    "base_expression_sdnf",
                    "base_expression_sknf",
                ),
            },
        ),
        ("Квайн", {"classes": ("collapse",), "fields": ("quine_sdnf", "quine_sknf")}),
        (
            "Квайн–МакКласки",
            {
                "classes": ("collapse",),
                "fields": (
                    "quine_mccluskey_sdnf",
                    "quine_mccluskey_sknf",
                ),
            },
        ),
    )

    # created_at auto_now_add, но в админке пусть будет readonly (для аккуратности)
    readonly_fields = ("created_at",)


@admin.register(Variant)
class VariantAdmin(admin.ModelAdmin):
    list_display = ("id", "karnaugh_letter", "karnaugh_offset", "base_type", "answers")
    list_filter = ("base_type", "karnaugh_letter")
    search_fields = ("karnaugh_letter",)
    autocomplete_fields = ("answers",)
    list_select_related = ("answers",)

    formfield_overrides = {
        JSONField: {"widget": PrettyJSONWidget(attrs={"rows": 12, "cols": 100})},
    }  # JSONField в админке часто делают с кастом-виджетом для читаемости [web:13]


@admin.register(ResultsBC3)
class ResultsBC3Admin(admin.ModelAdmin):
    date_hierarchy = "created_at"
    ordering = ("-created_at",)
    list_display = ("id", "user", "created_at", "rating", "result_number")
    list_filter = ("created_at",)
    search_fields = ("user__username",)
    autocomplete_fields = ("user",)

    readonly_fields = ("created_at",)

    fieldsets = (
        ("Общее", {"fields": ("user", "created_at", "rating", "result_number")}),
        (
            "Пары",
            {
                "classes": ("collapse",),
                "fields": tuple(
                    f for i in range(16) for f in (f"pair_0_{i}", f"pair_2_{i}")
                ),
            },
        ),
        (
            "Карта Карно",
            {"classes": ("collapse",), "fields": tuple(f"cell_{i}" for i in range(16))},
        ),
        (
            "Минимальные формы",
            {
                "classes": ("collapse",),
                "fields": (
                    "sdnf",
                    "sknf",
                    "base_expression_sdnf",
                    "base_expression_sknf",
                ),
            },
        ),
        ("Квайн", {"classes": ("collapse",), "fields": ("quine_sdnf", "quine_sknf")}),
        (
            "Квайн–МакКласки",
            {
                "classes": ("collapse",),
                "fields": (
                    "quine_mccluskey_sdnf",
                    "quine_mccluskey_sknf",
                ),
            },
        ),
    )


@admin.register(BorderControl3)
class BorderControl3Admin(admin.ModelAdmin):
    date_hierarchy = "created_at"
    ordering = ("-created_at",)
    list_display = (
        "id",
        "user",
        "variant",
        "created_at",
        "rating",
        "result_number",
        "results",
    )
    list_filter = ("created_at",)
    search_fields = ("user__username",)
    autocomplete_fields = ("user", "variant", "results")
    list_select_related = ("user", "variant", "results")

    readonly_fields = ("created_at",)

    fieldsets = (
        ("Общее", {"fields": ("user", "variant", "created_at")}),
        ("Итоги", {"fields": ("results", "rating", "result_number")}),
    )
