from django.http import HttpResponse
from django.views.generic import TemplateView
from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import BorderControl3Form
from .helpers import create_karnaugh_control, get_karnaugh_results_and_rating
from .models import BorderControl3, ResultsBC3, AnswersBC3
from automata_theory.models import BCFile, KRTime


class BorderControl3View(LoginRequiredMixin, TemplateView):
    form_class = BorderControl3Form
    template_name = "test3.html"

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)

        # Создаем контрольную работу для пользователя
        control = create_karnaugh_control(self.request.user)

        # Получаем список значений (таблицу истинности)
        truth_table = control.truth_table

        # Создаем пары условий для таблицы на основе списка
        condition_pairs = []
        for i in range(16):
            # Преобразуем индекс в 4-битный двоичный код (X1, X2, X3, X4)
            binary = format(i, "04b")
            x1, x2, x3, x4 = binary

            # Получаем значение из таблицы истинности
            value = truth_table[i] if i < len(truth_table) else "0"

            condition_pairs.append((i, (x1, x2, x3, x4), value))

        # Подготавливаем начальные данные для формы
        initial_data = {}

        # Добавляем пустые значения для текстовых полей
        text_fields = [
            "sdnf",
            "sknf",
            "quine_sdnf",
            "quine_sknf",
            "quine_mccluskey_sdnf",
            "quine_mccluskey_sknf",
        ]
        for field in text_fields:
            initial_data[field] = ""

        # Оставляем поля base_expression пустыми
        initial_data["base_expression_sdnf"] = ""
        initial_data["base_expression_sknf"] = ""

        # Добавляем начальные значения для карты Карно (0 или пусто)
        for i in range(16):
            initial_data[f"cell_{i}"] = "0"  # или '' для полностью пустых полей

        # Инициализируем поля таблицы истинности пустыми значениями
        for i in range(16):
            # Для поля pair_0_i - оставляем пустым (не предзаполняем правильным значением)
            initial_data[f"pair_0_{i}"] = ""

            # Для поля pair_2_i - оставляем пустым
            initial_data[f"pair_2_{i}"] = ""

        # Инициализируем форму с подготовленными данными
        form = self.form_class(initial=initial_data)

        context.update(
            {
                "condition_pairs": condition_pairs,
                "truth_table": truth_table,
                "karnaugh_letter": control.karnaugh_letter,
                "karnaugh_offset": control.karnaugh_offset,
                "base_type": control.base_type,
                "base_display": dict(BorderControl3.BASE_TYPES).get(
                    control.base_type, control.base_type
                ),
                "form": form,
                "pagename": "Контрольная работа №3 - Карты Карно",
            }
        )

        # Получаем длительность контрольной работы
        kr_time = KRTime.objects.filter(kr_number=3, is_active=True).last()
        if kr_time:
            context["kr_duration"] = str(kr_time.duration)
        else:
            context["kr_duration"] = "00:45:00"

        return context

    def post(self, request, *args, **kwargs):
        try:
            control = (
                BorderControl3.objects.filter(user=request.user)
                .order_by("-created_at")
                .first()
            )
        except BorderControl3.DoesNotExist:
            messages.error(
                request, "Контрольная работа не найдена. Пожалуйста, начните заново."
            )
            return redirect("border_control3")

        if not control:
            messages.error(
                request, "Контрольная работа не найдена. Пожалуйста, начните заново."
            )
            return redirect("border_control3")

        # Собираем значения из ВСЕХ полей таблицы
        truth_table_values = []
        pair_0_values = []  # Индексы (если нужны для проверки)

        for i in range(16):
            # Получаем оба значения
            pair_0_val = request.POST.get(
                f"pair_0_{i}", "0"
            )  # индекс (обычно от 0 до 15)
            pair_2_val = request.POST.get(
                f"pair_2_{i}", "0"
            )  # значение таблицы истинности

            pair_0_values.append(pair_0_val)
            truth_table_values.append(pair_2_val)

        # Можно добавить проверку индексов (опционально)
        for i in range(16):
            if pair_0_values[i] != str(i):
                # Индекс не совпадает, можно обработать ошибку
                pass

        # Формируем карту Карно из таблицы истинности
        # (порядок зависит от вашей реализации карты Карно)
        karnaugh_cells = []
        # Прямой порядок или преобразованный
        for i in range(16):
            karnaugh_cells.append(truth_table_values[i])

        # Либо если нужен особый порядок для карты Карно 4x4:
        # karnaugh_order = [0, 1, 3, 2, 4, 5, 7, 6, 12, 13, 15, 14, 8, 9, 11, 10]
        # for order_index in karnaugh_order:
        #     karnaugh_cells.append(truth_table_values[order_index])

        # Создаем объект результатов
        results = ResultsBC3.objects.create(
            user=request.user,
            # Значения карты Карно (из pair_2 значений)
            cell_0=karnaugh_cells[0] if len(karnaugh_cells) > 0 else "0",
            cell_1=karnaugh_cells[1] if len(karnaugh_cells) > 1 else "0",
            cell_2=karnaugh_cells[2] if len(karnaugh_cells) > 2 else "0",
            cell_3=karnaugh_cells[3] if len(karnaugh_cells) > 3 else "0",
            cell_4=karnaugh_cells[4] if len(karnaugh_cells) > 4 else "0",
            cell_5=karnaugh_cells[5] if len(karnaugh_cells) > 5 else "0",
            cell_6=karnaugh_cells[6] if len(karnaugh_cells) > 6 else "0",
            cell_7=karnaugh_cells[7] if len(karnaugh_cells) > 7 else "0",
            cell_8=karnaugh_cells[8] if len(karnaugh_cells) > 8 else "0",
            cell_9=karnaugh_cells[9] if len(karnaugh_cells) > 9 else "0",
            cell_10=karnaugh_cells[10] if len(karnaugh_cells) > 10 else "0",
            cell_11=karnaugh_cells[11] if len(karnaugh_cells) > 11 else "0",
            cell_12=karnaugh_cells[12] if len(karnaugh_cells) > 12 else "0",
            cell_13=karnaugh_cells[13] if len(karnaugh_cells) > 13 else "0",
            cell_14=karnaugh_cells[14] if len(karnaugh_cells) > 14 else "0",
            cell_15=karnaugh_cells[15] if len(karnaugh_cells) > 15 else "0",
            # Минимальные формы
            sdnf=request.POST.get("sdnf", ""),
            sknf=request.POST.get("sknf", ""),
            base_expression_sdnf=request.POST.get("base_expression_sdnf", ""),
            base_expression_sknf=request.POST.get("base_expression_sknf", ""),
            # Метод Квайна
            quine_sdnf=request.POST.get("quine_sdnf", ""),
            quine_sknf=request.POST.get("quine_sknf", ""),
            # Метод Квайна-МакКласки
            quine_mccluskey_sdnf=request.POST.get("quine_mccluskey_sdnf", ""),
            quine_mccluskey_sknf=request.POST.get("quine_mccluskey_sknf", ""),
        )

        # Получаем правильные ответы и вычисляем оценку
        rating, result_number = get_karnaugh_results_and_rating(control, results)

        # Обновляем результаты
        results.rating = rating
        results.result_number = result_number
        results.save()

        # Связываем результаты с контрольной работой
        control.results = results
        control.rating = rating
        control.result_number = result_number
        control.save()

        files = request.FILES.getlist("bc_files")
        for file in files:
            BCFile.objects.create(
                user=request.user, kr_number=2, file=file, border_control_id=control.id
            ).save()

        messages.success(request, "Контрольная работа успешно отправлена")
        return redirect("account")
