from django.http import HttpResponse
from django.views.generic import TemplateView
from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import BorderControl3Form
from .helpers import create_karnaugh_control, get_karnaugh_results_and_rating
from .models import BorderControl3, ResultsBC3, AnswersBC3
from automata_theory.models import KRTime


class BorderControl3View(LoginRequiredMixin, TemplateView):
    form_class = BorderControl3Form
    template_name = "test3.html"

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)

        # Создаем контрольную работу для пользователя
        control = create_karnaugh_control(self.request.user)

        # Получаем список значений (таблицу истинности)
        truth_table = control.truth_table

        # Создаем пары условий для таблицы на основе списка
        condition_pairs = []
        for i in range(16):
            # Преобразуем индекс в 4-битный двоичный код (X1, X2, X3, X4)
            binary = format(i, '04b')
            x1, x2, x3, x4 = binary

            # Получаем значение из таблицы истинности
            value = truth_table[i] if i < len(truth_table) else '0'

            condition_pairs.append((i, (x1, x2, x3, x4), value))

        # Подготавливаем начальные данные для формы
        initial_data = {}

        # Добавляем пустые значения для текстовых полей
        text_fields = ['sdnf', 'sknf', 'quine_sdnf', 'quine_sknf', 'quine_mccluskey_sdnf', 'quine_mccluskey_sknf']
        for field in text_fields:
            initial_data[field] = ''

        # Инициализируем форму с подготовленными данными
        form = self.form_class(initial=initial_data)

        context.update({
            "condition_pairs": condition_pairs,
            "truth_table": truth_table,
            "karnaugh_letter": control.karnaugh_letter,
            "karnaugh_offset": control.karnaugh_offset,
            "base_type": control.base_type,
            "base_display": dict(BorderControl3.BASE_TYPES).get(control.base_type, control.base_type),
            "form": form,
            "pagename": "Контрольная работа №3 - Карты Карно",
        })

        # Получаем длительность контрольной работы
        kr_time = KRTime.objects.filter(kr_number=3, is_active=True).last()
        if kr_time:
            context["kr_duration"] = str(kr_time.duration)
        else:
            context["kr_duration"] = "00:45:00"

        return context

    def post(self, request, *args, **kwargs):
        # Получаем активную контрольную работу пользователя (последнюю созданную)
        try:
            control = BorderControl3.objects.filter(user=request.user).order_by('-created_at').first()
        except BorderControl3.DoesNotExist:
            messages.error(request, "Контрольная работа не найдена. Пожалуйста, начните заново.")
            return redirect('border_control3')

        if not control:
            messages.error(request, "Контрольная работа не найдена. Пожалуйста, начните заново.")
            return redirect('border_control3')

        # Создаем объект результатов
        results = ResultsBC3.objects.create(
            user=request.user,

            # Значения карты Карно
            cell_0=request.POST.get("cell_0", "0"),
            cell_1=request.POST.get("cell_1", "0"),
            cell_2=request.POST.get("cell_2", "0"),
            cell_3=request.POST.get("cell_3", "0"),
            cell_4=request.POST.get("cell_4", "0"),
            cell_5=request.POST.get("cell_5", "0"),
            cell_6=request.POST.get("cell_6", "0"),
            cell_7=request.POST.get("cell_7", "0"),
            cell_8=request.POST.get("cell_8", "0"),
            cell_9=request.POST.get("cell_9", "0"),
            cell_10=request.POST.get("cell_10", "0"),
            cell_11=request.POST.get("cell_11", "0"),
            cell_12=request.POST.get("cell_12", "0"),
            cell_13=request.POST.get("cell_13", "0"),
            cell_14=request.POST.get("cell_14", "0"),
            cell_15=request.POST.get("cell_15", "0"),

            # Минимальные формы
            sdnf=request.POST.get("sdnf", ""),
            sknf=request.POST.get("sknf", ""),
            base_expression_sdnf = request.POST.get("base_expression_sdnf", ""),
            base_expression_sknf = request.POST.get("base_expression_sknf", ""),
            # Метод Квайна
            quine_sdnf=request.POST.get("quine_sdnf", ""),
            quine_sknf=request.POST.get("quine_sknf", ""),

            # Метод Квайна-МакКласки
            quine_mccluskey_sdnf=request.POST.get("quine_mccluskey_sdnf", ""),
            quine_mccluskey_sknf=request.POST.get("quine_mccluskey_sknf", ""),
        )

        # Получаем правильные ответы и вычисляем оценку
        rating, result_number = get_karnaugh_results_and_rating(control, results)

        # Обновляем результаты
        results.rating = rating
        results.result_number = result_number
        results.save()

        # Связываем результаты с контрольной работой
        control.results = results
        control.rating = rating
        control.result_number = result_number
        control.save()

        messages.success(request, "Контрольная работа успешно отправлена")
        return redirect("account")