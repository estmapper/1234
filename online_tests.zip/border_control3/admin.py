from django.contrib import admin
from .models import BorderControl3, ResultsBC3, AnswersBC3


@admin.register(BorderControl3)
class BorderControl3Admin(admin.ModelAdmin):
    list_display = ['user', 'karnaugh_letter', 'karnaugh_offset', 'base_type', 'created_at', 'get_rating',
                    'result_number']
    list_filter = ['base_type', 'created_at', 'karnaugh_letter']
    search_fields = ['user__username', 'user__first_name', 'user__last_name']
    readonly_fields = ['created_at']

    def get_rating(self, obj):
        return obj.rating if obj.rating else "Не оценено"

    get_rating.short_description = 'Оценка'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'answers', 'results')


@admin.register(AnswersBC3)
class AnswersBC3Admin(admin.ModelAdmin):
    list_display = ['created_at', 'get_tests_count']
    list_filter = ['created_at']
    readonly_fields = ['created_at']
    fieldsets = (
        ('Основная информация', {
            'fields': ('created_at',)
        }),
        ('Правильная карта Карно', {
            'fields': (
                ('cell_0', 'cell_1', 'cell_2', 'cell_3'),
                ('cell_4', 'cell_5', 'cell_6', 'cell_7'),
                ('cell_8', 'cell_9', 'cell_10', 'cell_11'),
                ('cell_12', 'cell_13', 'cell_14', 'cell_15'),
            )
        }),
        ('Правильные минимальные формы', {
            'fields': ('sdnf', 'sknf')
        }),
        ('Правильные формы метода Квайна', {
            'fields': ('quine_sdnf', 'quine_sknf')
        }),
        ('Правильные формы метода Квайна-МакКласки', {
            'fields': ('quine_mccluskey_sdnf', 'quine_mccluskey_sknf')
        }),
    )

    def get_tests_count(self, obj):
        return obj.get_tests().count()

    get_tests_count.short_description = 'Количество тестов'


@admin.register(ResultsBC3)
class ResultsBC3Admin(admin.ModelAdmin):
    list_display = ['user', 'created_at', 'get_test_info', 'get_rating', 'result_number']
    list_filter = ['created_at', 'rating']
    search_fields = ['user__username', 'user__first_name', 'user__last_name']
    readonly_fields = ['created_at']
    fieldsets = (
        ('Основная информация', {
            'fields': ('user', 'created_at', 'rating', 'result_number')
        }),
        ('Карта Карно', {
            'fields': (
                ('cell_0', 'cell_1', 'cell_2', 'cell_3'),
                ('cell_4', 'cell_5', 'cell_6', 'cell_7'),
                ('cell_8', 'cell_9', 'cell_10', 'cell_11'),
                ('cell_12', 'cell_13', 'cell_14', 'cell_15'),
            )
        }),
        ('Минимальные формы', {
            'fields': ('sdnf', 'sknf', 'base_expression_sknf', 'base_expression_sdnf')
        }),
        ('Метод Квайна', {
            'fields': ('quine_sdnf', 'quine_sknf')
        }),
        ('Метод Квайна-МакКласки', {
            'fields': ('quine_mccluskey_sdnf', 'quine_mccluskey_sknf')
        }),
    )

    def get_test_info(self, obj):
        test = obj.get_test()
        if test:
            return f"{test.karnaugh_letter} (смещение: {test.karnaugh_offset})"
        return "Нет связи с тестом"

    get_test_info.short_description = 'Тест'

    def get_rating(self, obj):
        return obj.rating if obj.rating else "Не оценено"

    get_rating.short_description = 'Оценка'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')