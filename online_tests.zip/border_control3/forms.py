from django import forms

class BorderControl3Form(forms.Form):
    """Form for Border Control 3 - Karnaugh Maps and Quine-McCluskey"""
    # Base type selection
    base_type = forms.ChoiceField(
        label="Базис",
        choices=[
            ('and_or_not', 'И-ИЛИ-НЕ'),
            ('not_and', 'Штрих Шеффера (И-НЕ)'),
            ('not_or', 'Стрелка Пирса (ИЛИ-НЕ)')
        ],
        widget=forms.Select(attrs={"class": "form-select"}),
        required=True
    )
    
    # Karnaugh map cells (16 cells for 4x4 grid)
    cell_0 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_1 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_2 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_3 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_4 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_5 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_6 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_7 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_8 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_9 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_10 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_11 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_12 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_13 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_14 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    cell_15 = forms.CharField(required=True, max_length=1, widget=forms.TextInput(attrs={'class': 'karnaugh-input'}))
    
    # Minimized expressions
    sdnf = forms.CharField(
        label="Минимальная СДНФ",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    sknf = forms.CharField(
        label="Минимальная СКНФ",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    # Quine method solutions
    quine_sdnf = forms.CharField(
        label="СДНФ по методу Квайна",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    quine_sknf = forms.CharField(
        label="СКНФ по методу Квайна",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    # Quine-McCluskey method solutions
    quine_mccluskey_sdnf = forms.CharField(
        label="СДНФ по методу Квайна-МакКласки",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    quine_mccluskey_sknf = forms.CharField(
        label="СКНФ по методу Квайна-МакКласки",
        widget=forms.TextInput(attrs={"class": "form-control"}),
        max_length=500,
        required=True
    )
    
    def clean(self):
        cleaned_data = super().clean()
        
        # Validate Karnaugh map cells (0, 1, or x)
        for i in range(16):
            cell_value = cleaned_data.get(f'cell_{i}', '').strip().lower()
            if cell_value not in ['0', '1', 'x']:
                self.add_error(f'cell_{i}', 'Допустимые значения: 0, 1 или x')
            else:
                # Update the cleaned data with the normalized value
                cleaned_data[f'cell_{i}'] = cell_value
        
        return cleaned_data